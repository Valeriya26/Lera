﻿namespace WindowsFormsApp2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bdDataSet1 = new WindowsFormsApp2.BDDataSet();
            this.militaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.militaryTableAdapter = new WindowsFormsApp2.BDDataSetTableAdapters.MilitaryTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bdDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.militaryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bdDataSet1
            // 
            this.bdDataSet1.DataSetName = "BDDataSet";
            this.bdDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // militaryBindingSource
            // 
            this.militaryBindingSource.DataMember = "Military";
            this.militaryBindingSource.DataSource = this.bdDataSet1;
            // 
            // militaryTableAdapter
            // 
            this.militaryTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(161, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 72);
            this.button1.TabIndex = 0;
            this.button1.Text = "Просмотр таблиц";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 312);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bdDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.militaryBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource charterGuardServiceBindingSource;
        private BDDataSet bDDataSet;
        private BDDataSet bdDataSet1;
        private System.Windows.Forms.BindingSource militaryBindingSource;
        private BDDataSetTableAdapters.MilitaryTableAdapter militaryTableAdapter;
        private System.Windows.Forms.Button button1;
    }
}