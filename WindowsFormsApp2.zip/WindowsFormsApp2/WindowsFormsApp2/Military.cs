﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Military : Form
    {
        public Military()
        {
            InitializeComponent();
        }

        private void Military_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Military". При необходимости она может быть перемещена или удалена.
            this.militaryTableAdapter.Fill(this.bDDataSet.Military);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Military". При необходимости она может быть перемещена или удалена.
            this.militaryTableAdapter.Fill(this.bDDataSet.Military);

        }

        private void militaryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.militaryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDDataSet);

        }
    }
}
