﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Weapon : Form
    {
        public Weapon()
        {
            InitializeComponent();
        }

        private void Weapon_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Weapon". При необходимости она может быть перемещена или удалена.
            this.weaponTableAdapter.Fill(this.bDDataSet.Weapon);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Weapon". При необходимости она может быть перемещена или удалена.
            this.weaponTableAdapter.Fill(this.bDDataSet.Weapon);

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void weaponBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.weaponBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDDataSet);

        }
    }
}
