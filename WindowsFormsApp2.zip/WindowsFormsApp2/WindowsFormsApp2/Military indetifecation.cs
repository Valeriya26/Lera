﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Military_indetifecation : Form
    {
        public Military_indetifecation()
        {
            InitializeComponent();
        }

        private void Military_indetifecation_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Military_identification". При необходимости она может быть перемещена или удалена.
            this.military_identificationTableAdapter.Fill(this.bDDataSet.Military_identification);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Military_identification". При необходимости она может быть перемещена или удалена.
            this.military_identificationTableAdapter.Fill(this.bDDataSet.Military_identification);

        }

        private void military_identificationBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.military_identificationBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDDataSet);

        }
    }
}
