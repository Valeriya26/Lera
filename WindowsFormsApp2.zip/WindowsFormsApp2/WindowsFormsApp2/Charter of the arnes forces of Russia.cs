﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Charter_of_the_arnes_forces_of_Russia : Form
    {

        private void Charter_of_the_armes_forces_of_Russia_Load(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            Form Charter_of_the_arnes_forces_of_Russia = new Form2();
            Charter_of_the_arnes_forces_of_Russia.ShowDialog();

        }

        public Charter_of_the_arnes_forces_of_Russia()
        {
            InitializeComponent();
        }

        private void Charter_of_the_arnes_forces_of_Russia_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Charter_of_the_armes_forces_of_Russian". При необходимости она может быть перемещена или удалена.
            this.charter_of_the_armes_forces_of_RussianTableAdapter.Fill(this.bDDataSet.Charter_of_the_armes_forces_of_Russian);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Charter_of_the_armes_forces_of_Russian". При необходимости она может быть перемещена или удалена.
            this.charter_of_the_armes_forces_of_RussianTableAdapter.Fill(this.bDDataSet.Charter_of_the_armes_forces_of_Russian);

        }

        private void bindingNavigatorCountItem_Click(object sender, EventArgs e)
        {

        }

        private void charter_of_the_armes_forces_of_RussianBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.charter_of_the_armes_forces_of_RussianBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDDataSet);

        }
    }
}
