﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Prosmotr_tablic : Form
    {
        public Prosmotr_tablic()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new Military();
            Form2.ShowDialog();
            
        }



        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new charter_guard_service();
            Form2.ShowDialog();
            
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new Military_indetifecation();
            Form2.ShowDialog();
            
        }

        private void Prosmotr_tablic_Load(object sender, EventArgs e)
        {
            Hide();
        }

 

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new Charter_of_the_arnes_forces_of_Russia();
            Form2.ShowDialog();

        }
        private void Prosmotr_tablic_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new Weapon();
            Form2.ShowDialog();

        }
    }
}
