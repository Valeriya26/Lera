﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class charter_guard_service : Form
    {
        public charter_guard_service()
        {
            InitializeComponent();
        }

        private void charter_guard_service_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.charter_guard_service". При необходимости она может быть перемещена или удалена.
            this.charter_guard_serviceTableAdapter.Fill(this.bDDataSet.charter_guard_service);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.charter_guard_service". При необходимости она может быть перемещена или удалена.
            this.charter_guard_serviceTableAdapter.Fill(this.bDDataSet.charter_guard_service);

        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void charter_guard_serviceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.charter_guard_serviceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDDataSet);

        }
    }
}
